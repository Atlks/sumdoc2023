 [.net6 webapi.md](.net6%20webapi.md)  <br>
 [2022 binly med recd.md](2022%20binly%20med%20recd.md)  <br>
 [api 增强util的api.md](api%20增强util的api.md)  <br>
 [app容器技术.md](app容器技术.md)  <br>
 [app dev effc 集成cli模式 lib.md](app%20dev%20effc%20集成cli模式%20lib.md)  <br>
 [api 设计原则总结.md](api%20设计原则总结.md)  <br>
 [asyn to sync meth.md](asyn%20to%20sync%20meth.md)  <br>
 [async await useage.md](async%20await%20useage.md)  <br>
 [await async 异步模式.md](await%20async%20异步模式.md)  <br>
 [bddbt hwijo 2021 2022 .md](bddbt%20hwijo%202021%202022%20.md)  <br>
 [bookmarks_2022_11_30.html](bookmarks_2022_11_30.html)  <br>
 [bookmarks_2022_11_28.html](bookmarks_2022_11_28.html)  <br>
 [bookmarks_2022_12_1.html](bookmarks_2022_12_1.html)  <br>
 [bookmarks_2022_12_10.html](bookmarks_2022_12_10.html)  <br>
 [bookmarks_2022_12_14.html](bookmarks_2022_12_14.html)  <br>
 [bookmarks_2022_12_17.html](bookmarks_2022_12_17.html)  <br>
 [bookmarks_2022_12_15.html](bookmarks_2022_12_15.html)  <br>
 [bookmarks_2022_12_2.html](bookmarks_2022_12_2.html)  <br>
 [bookmarks_2022_12_6.html](bookmarks_2022_12_6.html)  <br>
 [bookmarks_2022_12_8.html](bookmarks_2022_12_8.html)  <br>
 [cinson gonza.md](cinson%20gonza.md)  <br>
 [cio 工作范围.md](cio%20工作范围.md)  <br>
 [CIO 的 工作内容.md](CIO%20的%20工作内容.md)  <br>
 [cld pltfm.md](cld%20pltfm.md)  <br>
 [common sub sys.md](common%20sub%20sys.md)  <br>
 [db mng数据库管理提升可读性.md](db%20mng数据库管理提升可读性.md)  <br>
 [Dart、CoffeeScript、TypeScript 和JavaScript.md](Dart、CoffeeScript、TypeScript%20和JavaScript.md)  <br>
 [dabao 打包技术索引目录.md](dabao%20打包技术索引目录.md)  <br>
 [db 数据库类型.md](db%20数据库类型.md)  <br>
 [dev efk api qry lan api查询语言dsl GraphQL.md](dev%20efk%20api%20qry%20lan%20api查询语言dsl%20GraphQL.md)  <br>
 [dev mng 开发中的管理.md](dev%20mng%20开发中的管理.md)  <br>
 [dev way zidao.md](dev%20way%20zidao.md)  <br>
 [doc sync 文档同步工具.md](doc%20sync%20文档同步工具.md)  <br>
 [doc type文档类型.md](doc%20type文档类型.md)  <br>
 [docker容器.md](docker容器.md)  <br>
 [easy travel work.md](easy%20travel%20work.md)  <br>
 [EditorConfig编码文本加载保存规范.md](EditorConfig编码文本加载保存规范.md)  <br>
 [favorites_2022_11_28.html](favorites_2022_11_28.html)  <br>
 [embed lan嵌入式语言互相调用.md](embed%20lan嵌入式语言互相调用.md)  <br>
 [favorites_2022_11_30.html](favorites_2022_11_30.html)  <br>
 [favorites_2022_12_1.html](favorites_2022_12_1.html)  <br>
 [favorites_2022_12_10.html](favorites_2022_12_10.html)  <br>
 [favorites_2022_12_16.html](favorites_2022_12_16.html)  <br>
 [favorites_2022_12_2.html](favorites_2022_12_2.html)  <br>
 [favorites_2022_12_17.html](favorites_2022_12_17.html)  <br>
 [favorites_2022_12_6.html](favorites_2022_12_6.html)  <br>
 [favorites_2022_12_5.html](favorites_2022_12_5.html)  <br>
 [fltr doc.md](fltr%20doc.md)  <br>
 [fltr env.md](fltr%20env.md)  <br>
 [favorites_2022_12_8.html](favorites_2022_12_8.html)  <br>
 [im的简化设计总结.md](im的简化设计总结.md)  <br>
 [IDEA打包jar包详尽流程.md](IDEA打包jar包详尽流程.md)  <br>
 [index.html](index.html)  <br>
 [java lib.md](java%20lib.md)  <br>
 [js libs.md](js%20libs.md)  <br>
 [java 微服务 轻量级.md](java%20微服务%20轻量级.md)  <br>
 [mgdb gui mongosh use.md](mgdb%20gui%20mongosh%20use.md)  <br>
 [Markdown 基本语法.md](Markdown%20基本语法.md)  <br>
 [lst table jqry.md](lst%20table%20jqry.md)  <br>
 [mgdb java exmp.md](mgdb%20java%20exmp.md)  <br>
 [mgdb mng.md](mgdb%20mng.md)  <br>
 [mmnc to addr.md](mmnc%20to%20addr.md)  <br>
 [mongodb和mysql数据文件的异同.md](mongodb和mysql数据文件的异同.md)  <br>
 [my tech domain 方向drkt.md](my%20tech%20domain%20方向drkt.md)  <br>
 [mysql mongodb redis 性能慢的原因与调优.md](mysql%20mongodb%20redis%20性能慢的原因与调优.md)  <br>
 [mysql perf enhs.md](mysql%20perf%20enhs.md)  <br>
 [node.js op mongodb .md](node.js%20op%20mongodb%20.md)  <br>
 [netcore webapi port setting.md](netcore%20webapi%20port%20setting.md)  <br>
 [node.js读写sqlite最佳实践.md](node.js读写sqlite最佳实践.md)  <br>
 [node.js 同步写法最佳实践.md](node.js%20同步写法最佳实践.md)  <br>
 [mysql 性能优化.md](mysql%20性能优化.md)  <br>
 [nodejs useful lib.md](nodejs%20useful%20lib.md)  <br>
 [node.js连接mongodb最佳实践wb8.md](node.js连接mongodb最佳实践wb8.md)  <br>
 [nosql mongodb简化开发的原理.md](nosql%20mongodb简化开发的原理.md)  <br>
 [node打包为exe文件.md](node打包为exe文件.md)  <br>
 [Redis 存储对象信息是用 Hash 还是 String.md](Redis%20存储对象信息是用%20Hash%20还是%20String.md)  <br>
 [rocketmq inst 安装文档.md](rocketmq%20inst%20安装文档.md)  <br>
 [sinjyabi gaode nvren.md](sinjyabi%20gaode%20nvren.md)  <br>
 [safe cost mng.md](safe%20cost%20mng.md)  <br>
 [sprbt halowld.md](sprbt%20halowld.md)  <br>
 [sqlt mysql性能对比5倍左右.md](sqlt%20mysql性能对比5倍左右.md)  <br>
 [ui布局xml模式vs代码模式.md](ui布局xml模式vs代码模式.md)  <br>
 [ui库和webapi和后端程序.md](ui库和webapi和后端程序.md)  <br>
 [Untitled-1.md](Untitled-1.md)  <br>
 [use npm node lib in browser.md](use%20npm%20node%20lib%20in%20browser.md)  <br>
 [ui接口技术gui cli cui api.md](ui接口技术gui%20cli%20cui%20api.md)  <br>
 [vm 虚拟机之道.md](vm%20虚拟机之道.md)  <br>
 [wb1 frg.md](wb1%20frg.md)  <br>
 [一编程语言 开发效率 功能点时间。.md](一编程语言%20开发效率%20功能点时间。.md)  <br>
 [事务 SAVEPOINT来实现内嵌事务.md](事务%20SAVEPOINT来实现内嵌事务.md)  <br>
 [事务中途停机的后记恢复处理.md](事务中途停机的后记恢复处理.md)  <br>
 [使用全文索引和like简化表设计 关联表 一对多多对多关系.md](使用全文索引和like简化表设计%20关联表%20一对多多对多关系.md)  <br>
 [免安装数据库与管理科.md](免安装数据库与管理科.md)  <br>
 [减少切换pc手机it设备时候的迁移app数量.md](减少切换pc手机it设备时候的迁移app数量.md)  <br>
 [全球化战略转型要点.md](全球化战略转型要点.md)  <br>
 [分布式技术.md](分布式技术.md)  <br>
 [分库分表优缺点.md](分库分表优缺点.md)  <br>
 [分库分表后 跨节点关联查询 join 问题.md](分库分表后%20跨节点关联查询%20join%20问题.md)  <br>
 [分库分表如何做数据迁移？.md](分库分表如何做数据迁移？.md)  <br>
 [分库分表带来的问题.md](分库分表带来的问题.md)  <br>
 [分表模式 通过userid分表分库.md](分表模式%20通过userid分表分库.md)  <br>
 [判断IEnumerable 是否为空.md](判断IEnumerable%20是否为空.md)  <br>
 [单表容量与btree树高的关联.md](单表容量与btree树高的关联.md)  <br>
 [后端backend common mod常用模块.md](后端backend%20common%20mod常用模块.md)  <br>
 [大数据下tidb选择.md](大数据下tidb选择.md)  <br>
 [垃圾回收的几种策略.md](垃圾回收的几种策略.md)  <br>
 [大数据量下分表模式 按照uid分表.md](大数据量下分表模式%20按照uid分表.md)  <br>
 [好用的编程插件与自动化ide.txt.md](好用的编程插件与自动化ide.txt.md)  <br>
 [如何解决不付款尾款问题 留后门时间戳.md](如何解决不付款尾款问题%20留后门时间戳.md)  <br>
 [密码管理.md](密码管理.md)  <br>
 [工作生活通用技术.md](工作生活通用技术.md)  <br>
 [常见架构 JAMstack lnmp lamp.md](常见架构%20JAMstack%20lnmp%20lamp.md)  <br>
 [开发效率杀手mvc.md](开发效率杀手mvc.md)  <br>
 [快速开发本地json数据库.md](快速开发本地json数据库.md)  <br>
 [异步future task promise。。async await.md](异步future%20task%20promise。。async%20await.md)  <br>
 [性能提升 提升你的机器性能.md](性能提升%20提升你的机器性能.md)  <br>
 [快速开发架构选型.md](快速开发架构选型.md)  <br>
 [扩展性与可读性.md](扩展性与可读性.md)  <br>
 [技术提升的几大技术点.md](技术提升的几大技术点.md)  <br>
 [技术提升.md](技术提升.md)  <br>
 [接口权限autu api.md](接口权限autu%20api.md)  <br>
 [提升mysql性能写入性能.md](提升mysql性能写入性能.md)  <br>
 [提升可读性 fp函数编程.md](提升可读性%20fp函数编程.md)  <br>
 [提升可读性方法 技术 lib.md](提升可读性方法%20技术%20lib.md)  <br>
 [提升安全性 可用性.md](提升安全性%20可用性.md)  <br>
 [提升开发效率.md](提升开发效率.md)  <br>
 [提升可读性方法.md](提升可读性方法.md)  <br>
 [数字化转型战略.txt.md](数字化转型战略.txt.md)  <br>
 [提升稳定性 内存泄漏.md](提升稳定性%20内存泄漏.md)  <br>
 [数据库性能提升路线图.md](数据库性能提升路线图.md)  <br>
 [数据存储外部数据源sql查询.md](数据存储外部数据源sql查询.md)  <br>
 [数据触发操作实时数据库.md](数据触发操作实时数据库.md)  <br>
 [数据迁移策略 多读和多些.md](数据迁移策略%20多读和多些.md)  <br>
 [最小化系统api接口.md](最小化系统api接口.md)  <br>
 [本地测试环境说明glcmdly.md](本地测试环境说明glcmdly.md)  <br>
 [服务器支持多少并发.md](服务器支持多少并发.md)  <br>
 [权限设计简化设计.md](权限设计简化设计.md)  <br>
 [标准api 统一的数据库接口.md](标准api%20统一的数据库接口.md)  <br>
 [比较好用的脚本语言node.js.md](比较好用的脚本语言node.js.md)  <br>
 [比较好用的脚本语言node.md](比较好用的脚本语言node.md)  <br>
 [百亿用户并发架构读写.md](百亿用户并发架构读写.md)  <br>
 [简单的方式调试 脚本.md](简单的方式调试%20脚本.md)  <br>
 [登录验证的token模式.md](登录验证的token模式.md)  <br>
 [索引技术.md](索引技术.md)  <br>
 [结构化日志.md](结构化日志.md)  <br>
 [自定义索引系统 排序 的实现原理 提升性能.md](自定义索引系统%20排序%20的实现原理%20提升性能.md)  <br>
 [虚拟化技术 vm虚拟机.md](虚拟化技术%20vm虚拟机.md)  <br>
 [自己实现事务机制.md](自己实现事务机制.md)  <br>
 [衡量 软件项目规模的技术点功能点.md](衡量%20软件项目规模的技术点功能点.md)  <br>
 [解决高并发的问题.md](解决高并发的问题.md)  <br>
 [资料工具 目录化link化方便seo.md](资料工具%20目录化link化方便seo.md)  <br>
 [资源泄漏 内存泄漏解决方案 短生命周期.md](资源泄漏%20内存泄漏解决方案%20短生命周期.md)  <br>
 [软件开发最重要的几个重要有原则.md](软件开发最重要的几个重要有原则.md)  <br>
 [轻量化开发运维过程.md](轻量化开发运维过程.md)  <br>
 [轻量级工作开发运维 app 工具.md](轻量级工作开发运维%20app%20工具.md)  <br>
 [轻量级战略.txt.md](轻量级战略.txt.md)  <br>
 [通用技术 数据分析.txt.md](通用技术%20数据分析.txt.md)  <br>
 [防止 脚本语句 注入.md](防止%20脚本语句%20注入.md)  <br>
 [降低it成本的几项战略.md](降低it成本的几项战略.md)  <br>
 [项目成本管理.txt.md](项目成本管理.txt.md)  <br>
 [高并发 多库模式下sqlte和 mysql对比.md](高并发%20多库模式下sqlte和%20mysql对比.md)  <br>
 [高并发的几种模型协程 进程 队列任务 线程.md](高并发的几种模型协程%20进程%20队列任务%20线程.md)  <br>
