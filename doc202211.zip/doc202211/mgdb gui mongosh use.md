mgdb gui mongosh use


use <dbname>


//   qwuery 


db.colname.find().sort( { creatTime: -1 } )


