

close trans
但是默认情况下没有打开事务支持，因为事务支持对性能会有影响。可以通过以下语句，转换为支持事务的Maria引擎。ALTER TABLE `tablename` ENGINE=MARIA


prgrms  trans ,custom trans,,,can 

编程事务

