sql直接调用

调用php
php -r "xx;bbb;"




