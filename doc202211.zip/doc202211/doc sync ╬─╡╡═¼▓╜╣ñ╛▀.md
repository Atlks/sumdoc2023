doc sync 文档同步工具

<!-- TOC -->

- [stmap.cjs](#stmapcjs)
- [github page+ site map links.](#github-page-site-map-links)
- [gitbook](#gitbook)
- [语雀不错的，程序员也可以爱上写文档](#语雀不错的程序员也可以爱上写文档)
- [看云目前来看是国内最靠谱的选择，支持电子出版](#看云目前来看是国内最靠谱的选择支持电子出版)

<!-- /TOC -->

# stmap.cjs
gene idx.html thro cjs... stmap looks

eml pblc .gglblg n wordpres
# github page+ site map links.
例如：开源的 gitbook 就可以教你把一个个 Markdown 文件组织起来，弄成一本电子书。


# gitbook 
,upload mdzip,then open as pub as a blg
最近想找一个记笔记的软件，试了几款都觉得差点意思，后来看到别人用gitbook写的笔记就想试试
GitBook为免费用户提供

10个空间（可以私有也可以公开）
支持自定义域名


分享类似GitBook的在线文档创作平台 - 知乎
https://zhuanlan.zhihu.com/p/36294814
蹼GitBook。对于在线文档创作平台，当然还是首推GitBook.GitBook为免费用户提供.10个空间（可以私有也可以公开）. 支持自定义域名.gitbook本身是一个开源项目，你可以下载源代码自行搭建.GitBook对开源和非盈利团队提供五折优


中国有类似Gitbook的网站吗？ - 知乎
https://www.zhihu.com/question/59298202
蹼国内真正类似Gitbook的网站恐怕也只有看云了，基于MD和Git版本库，提供了文档写作、托管和电子出版解决方案，支持MD编辑模式和可视化编辑模式的切换，每个文档都有独
国内真正类似Gitbook的网站恐怕也只有看云了，基于MD和Git版本库，提供了文档写作、托管和电子出版解决方案，支持MD编辑模式和可视化编辑模式的切换，每个文档都有独立的Git版本库地址，支持文档成员和团队、企业。作为知识库管理还是比较适合的。


# 语雀不错的，程序员也可以爱上写文档

# 看云目前来看是国内最靠谱的选择，支持电子出版

看云为免费用户提供

不限量公开文档
0个私有文档
完整文档功能
官网地址：看云 | 专注技术文档在线创作、阅读、分享和托管


docsify

非常轻量级的文档，可以托管在Github page