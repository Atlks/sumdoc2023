秉承为开发者赋能的使命。在2020年 Build 大会上，微软首席执行官 Satya Nadella 表示，“GitHub 拥有超过5000万用户，Visual Studio Code 是最受开发者欢迎的代码编辑器。微软将为开发者打造最完整的开发工具链，结合 GitHub、Visual Studio 和 Azure，帮助开发者实现从想法到代码、从代码到云的
 

# 代码编辑器 vscode

## blogs gthb

web3 wlt
