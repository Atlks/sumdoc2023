sorucemng git
bug mng,spec mng
dot mng
svr mng...vps ,remote ,dba(mysql redis mongodb)
emsvr mecury xampp

user mng
