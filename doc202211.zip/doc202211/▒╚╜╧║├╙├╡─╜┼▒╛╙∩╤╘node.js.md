比较好用的脚本语言node.js

虽然php同步more easy,
but mongodb .dll ext is trouboleth
and debug is trouble

node add lib is more easy,and debug easy
only asyn is prblm..can use await slove..just ok.addjust is
need add async lib is ok..

# python 
