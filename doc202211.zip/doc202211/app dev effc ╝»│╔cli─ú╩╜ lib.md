﻿Music





• Alpine（电子邮件客户端）
• cmus（媒体播放器）
• Irssi（IRC客户端）
• Lynx（网页浏览器）
• Midnight Commander（文件管理器）
• Music on Console（媒体播放器）
• Mutt（电子邮件客户端）
• nano（文本编辑器）
• ne（文本编辑器）
• newsbeuter（RSS阅读器）
• ranger（文件管理器）
ftp
http curl
sql mysql.exe
redis-cli



控制台应用程序（console application）是一种设计用于纯文字计算机界面的计算机程序，例如文本终端、某些操作系统（Unix、DOS等）的命令行界面，或者大多数图形用户界面操作系统的基于文本界面（例如Microsoft Windows中的Win32控制台，Mac OS X中的终端和Unix中的xterm）。用户与控制台应用程序的交互通常只需使用键盘和显示屏，而图形用户界面的程序大多必须使用鼠标或其他指点设备。许多控制台应用程序（如命令行解释器）只是命令行工具，但也存在一些基于文本用户界面程序。

总的form界面。。使用url 参数式样提交参数


Aaa=1
Bbb=2
Ccc=3

