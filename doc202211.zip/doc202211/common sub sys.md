common sub sys


1、KopSoftWms  WMS仓库管理系统
这是一个开源免费WMS仓库管理系统。

ossn

wordpres

、ScheduleMasterCore 分布式任务调度系统
这是一个基于.Net Core构建的简单、跨平台、模块化的分布式任务调度系统。

3、Meiam.System  企业级的前后端分离权限框架
这是基于.NetCore开发的、构建的简单、跨平台、前后端分离的框架。

4、 Blog.Core 企业级权限管理应用框架
一个基于.Net 6.0开发的应用框架，采用前后端分离架构，集成了上百个模块。

5、Vue.NetCore  前后端分离的低代码快速开发框架
一个基于.Net Core构建的简单、跨平台快速开发框架。前后端封装了上千个常用类，方便扩展；集成了代码生成器，支持前后端业务代码生成，实现快速开发，提升工作效率。

小编给大家分享一下常见的PHP开源文档管理系统有哪些，希望大家阅读完这篇文章之后都有所收获，下面让我们一起去探讨吧！

WebShare

WebShare是一个采用Ajax+PHP技术开发的webFTP资源管理器。可以利用它来查看，复制，修改，新增和共享Web文档。

OpenGoo PHP开源文档管理系统

OpenGoo是一套基于ExtJs+XAMP（Apache、PHP、MySQL）开发的开源web office。适用于任何单位或个人创建，共享，协作维护和发布它们所有内部与外部文档。

relayb

relayb是一个Ajax目录管理器。支持拖放操作文件和文件夹。动态加载文件结构。文件上传提示进度条。缩略图查看包括PDF格式，支持多用户和多账号。

Simple Directory Listing

Simple Directory Listing提供一个类似于apache http服务器目录列表的文档管理界面。拥有复制，移动，删除，重命名，创建文件夹/文件。上传/下载文件，Unicode支持，缩略图查看，RSS发布等。

CKFinder

CKFinder是一个易于使用的Ajax文件管理器。提供文件夹树形结构（Folders tree）导航菜单，多语言支持（自动探测用），支持创建/重命名/删除文件和文件夹，集成FCKeditor在线编辑器。

phpWebFtp

phpWebFtp是一个基于Web的Ftp客户端，可以连接至任意Ftp服务器。内置22种语言包。易于在Binary/ASCII两种模式下切换。提供WYSIWYG文件编辑器用于编辑.htm文件。内置文件与目录下载模式。支持解压zip文件等。

CuteFlow

CuteFlow是一个基于Web的文档流转/工作流工具。用户定义好一个文档之后就会按指定的流程一步一步地转发给列表中的每一个用户。

Epiware

Epiware是一个AJAX支持的项目与文档管理Web应用系统。它提供了一套完整的文件管理功能包括文档上传，下载，版本控制，审核，变化通知和访问历史列表等。Epiware还为开发团队创建一个安全的信息交流与相互协作平台。

PHP Navigator

基于Web运用PHP+Ajax技术开发的PHP开源文档管理系统。它具有WindowsXP风格的操作界面。使你感觉像在Windows中。

DocMgr

DocMgr是一个基于PHP+Postgresql构建的Web文档管理系统。支持利用tsearch3对大部分流行的文档格式进行全文索引。它同样包含访问控制列表，用户权限管理和文件多级分组功能。

SimpleDoc

SimpleDoc是一个基于web的PHP开源文档管理系统。它的界面简单而且直观(以树的结构进行管理，运用Ajax技术使得当修改内容时不需要刷新浏览器)。SimpleDoc不需要数据库支持。

DocumentManager

Document Manager是一个包含权限管理与邮件提醒功能基于Web的文档管理器。无需要数据库支持。

KnowledgeTree

KnowledgeTree是一个开源基于Web的文档管理系统。它具有知识管理，文档版本控制，分层文档管理和支持一些流行的文件格式也可以自定文件类型等。

Owl Intranet Engine

Owl是一个多用户的PHP开源文档管理系统。它可对文件夹和文件设置权限，基于角色权限管理，具有易于使用并且简洁的用户操作与管理界面，能够对文件夹和文件 进行监控，支持对文本，MS-Word和PDF文件进行全文搜索，提供下载统计功能，数据库备份工具，新闻系统，版本控制，回收站，自定文档类型等等。