vm 虚拟机之道

<!-- TOC -->

- [vm组成](#vm组成)
- [vm的分类](#vm的分类)
- [dvm DB是个虚拟机啊](#dvm-db是个虚拟机啊)
- [web3 eth evm](#web3-eth-evm)
- [内存管理](#内存管理)
- [cpu管理](#cpu管理)
- [io 与网络](#io-与网络)
- [console  output](#console--output)

<!-- /TOC -->

# vm组成

虚拟机
cpu 内存 io磁盘 console(screen)
network api

# vm的分类

svm pvm
系统虚拟机-system virtual machines，
进程虚拟机process virtual machines
jvm



# dvm DB是个虚拟机啊
mysql 事务进程管理 kill  ，定时调度timer
内存管理
存储管理 io
network
console

# web3 eth evm

# 内存管理

第二部分（第2~5章）自动内存管理

详细讲解了Java的内存区域与内存溢出、垃圾收集器与内存分配策略、虚拟机性能监控与故障排除等与自动内存管理相关的内容，以及10余个经典的性能优化案例和优化方法；

# cpu管理

并发模型 线程模型 

第三部分（第6~9章）虚拟机执行子系统

深入分析了虚拟机执行子系统，包括类文件结构、虚拟机类加载机制、虚拟机字节码执行引擎，以及多个类加载及其执行子系统的实战案例；

# io 与网络

# console  output

ref
深入理解Java虚拟机（第3版） (豆瓣)
os原理