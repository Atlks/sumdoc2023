Cloud platforms
AWS maintains its lead as the most widely used cloud platform, but Google Cloud and Microsoft Azure made substantial gains from last year. It is worth noting that this is the first year that we broke out cloud platforms from our general platforms question.
All RespondentsProfessional Developers
62,061 responses
AWS	54.22%
Google Cloud Platform	31.05%
Microsoft Azure	30.77%
Heroku	24%
DigitalOcean	17.67%
IBM Cloud or Watson	2.55%
