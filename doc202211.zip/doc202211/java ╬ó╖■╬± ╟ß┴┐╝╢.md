java 微服务 轻量级


apache Spark很多人都会联想到大数据的处理，但是他也是支持用于做微服务


vert.x 细节