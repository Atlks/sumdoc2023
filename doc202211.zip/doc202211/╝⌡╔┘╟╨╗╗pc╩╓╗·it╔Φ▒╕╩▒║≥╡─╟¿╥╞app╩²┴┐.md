减少切换pc手机it设备时候的迁移app数量


## 云端化app ggl ms全家桶，一个acc zo ok..

## mini must app amt

## app 分散化，这样迁移时候就少了很多。。

## 多功能app 大力减少了app数量
## 按需安装