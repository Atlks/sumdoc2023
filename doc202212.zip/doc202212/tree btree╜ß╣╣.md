tree btree结构


folder
db table row>>sub table row>>
json嵌套
list嵌套
zeekeeper路径节点树形模式。。