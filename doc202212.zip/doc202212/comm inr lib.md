comm inr lib

str
collection
io file
ex
