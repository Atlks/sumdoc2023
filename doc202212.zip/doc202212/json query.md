json data query from

store as db to query 


sqlite spt json

jsondb mgdb couchdb 
本地json文档数据库
lowdb 
pgsql

node-little-db小型本地json文件数据库
Tiny local JSON database for Node and Electron
小型项目的小型本地 JSON 数据库

特点： node-little-db 小型本地json文件数据库，你不需要学习其他API，就像操作一个对象、数组一样操作它即可。
————————————————
Jsondb A Opensource, Java-based, In-Memory/Embedded ...

jsondb.io
https://jsondb.io
EJDB 2.0 — Embeddable JSON Database engine library
ejdb.org
https://ejdb.org
翻译此页
EJDB 2.0 — Embeddable JSON Database engine C library. Simple XPath like query language (JQL). Websockets / Android / iOS / Java / Dart / Flutter / Node.js ...