lib type 类库类型

<!-- TOC -->

- [功能类 增强可读性api 性能类api](#功能类-增强可读性api-性能类api)
  - [dsl增强](#dsl增强)
- [api类库  cli模式类库  远程类库中间件](#api类库--cli模式类库--远程类库中间件)
- [功能 分类 task mem io net output](#功能-分类-task-mem-io-net-output)
  - [vm组成](#vm组成)
  - [cpu 内存 io磁盘 console(screen)](#cpu-内存-io磁盘-consolescreen)
  - [network api （http)](#network-api-http)
  - [db存储类](#db存储类)
  - [debug](#debug)
- [按照编程范式 fp类api 过程类api oo类api](#按照编程范式-fp类api-过程类api-oo类api)

<!-- /TOC -->

# 功能类 增强可读性api 性能类api



## dsl增强

# api类库  cli模式类库  远程类库中间件
rds mgdb mq

# 功能 分类 task mem io net output

## vm组成

虚拟机
cpu 内存 io磁盘 console(screen)

##  cpu 内存 io磁盘 console(screen)
## network api （http)
## db存储类

## debug


# 按照编程范式 fp类api 过程类api oo类api








java lib