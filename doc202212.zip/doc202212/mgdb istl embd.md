mgdb istl embd

D:\mongodb-win32-x86_64-windows-4.4.17\bin\mongod.exe -dbpath d:\db