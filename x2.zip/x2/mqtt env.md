mqtt env


另外，官网还提供MQTT客户端工具，可以非常方便的提供测试，下载地址为http://www.eclipse.org/paho/components/tool 可以下载org.eclipse.paho.mqtt.utility-1.0.0.jar这个Jar包，进行双击运行：

