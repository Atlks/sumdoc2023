embd tmct useage


addContext vs addWEbapp

   Context ctx_webapp = tomcat.addContext("/", "D:\\im-server-core\\im-biz\\target\\");
        //  addWEbapp 更麻烦解压缩war包会

 addWEbapp also invk addContext       