hi perf rds mysql mgdb param list map

 | param | rds  param | mysql   prm | mgdb prm |
  | --- | ---- | ---- | --- |  
   | log fresh | appendfsync no | innodb_flush_log_at_trx_commit |param |
 | ist chk | set fornrKeyChk=0 uniqKey=0 | no?? |
  | iso lev | read uncommed | no||




rds looks chg also same..maybe dt all in mmr...not in dsk...so look same...
 appendfsync no  and   appendfsync always is same..timne........
 