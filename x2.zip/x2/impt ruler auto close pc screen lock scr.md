

win 11

set auto cls scr ,but open not need pwd...
set pc hibnt ,then open need pwd...

set scr saver,,but cant ,bcs daobe sys


set auto close pc at 6.30  ,,test is ok..
