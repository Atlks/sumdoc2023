impt rule new pc

schtasks /create /sc daily /st 18:35  /tn "close system desc" /tr "shutdown -s -t 120"



sc schedu...task pinlv...
tr task run