
db 通知机制的实现 countdown 和blockmq队列和 mq模式

<!-- TOC -->

- [1. countdown 和blockmq队列 实现本进程通知。。](#1-countdown-和blockmq队列-实现本进程通知)

<!-- /TOC -->

# 1. countdown 和blockmq队列 实现本进程通知。。
通过文件listen模式可以实现跨进程通知。。

blockmq队列+http 或者mq实现跨机器通知。。


存入数据库的时候，同时发出一个通知即可。。
