mkdn vscode use prblm solu


ctrl c ,ctrl v cant use 

maybe some ext bind key ,,so settting.key shorutcuy key>> remove the key bind when extsion

cant enter key ..

maybe some ext ...all markdown all in one ext disable..uninstall  .then ok 