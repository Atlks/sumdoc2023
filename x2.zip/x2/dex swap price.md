dex swap price

uni is ok

sushi is expsv



。鉴于 Uniswap 的定价模型和固定费率（每笔交易收 0.3%） ，你很难看到它能在竞争最激烈的资金池中竞争 —— Curve 既对稳定币交易进行了优化，而且每笔交易的收费仅为 0.04%。

