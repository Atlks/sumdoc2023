dbg method n tool

<!-- TOC -->

- [dbg method](#dbg-method)
    - [** method invoke trace n param](#-method-invoke-trace-n-param)
    - [use log dft gene log](#use-log-dft-gene-log)
    - [error invoke StackList  n cur param](#error-invoke-stacklist--n-cur-param)
    - [use api to trace invoke](#use-api-to-trace-invoke)
    - [use tool to trace meth(param)](#use-tool-to-trace-methparam)
- [.... log](#-log)
    - [web acc url n param](#web-acc-url-n-param)
    - [vm log dft no](#vm-log-dft-no)
    - [db log..mysql log](#db-logmysql-log)
- [trance lib api 各种拦截api aop](#trance-lib-api-各种拦截api-aop)
    - [web fltre machi](#web-fltre-machi)
    - [vm api invoke trance api](#vm-api-invoke-trance-api)
    - [db trigger,,](#db-trigger)
    - [api埋点](#api埋点)
- [gui tool](#gui-tool)
- [java dbg tool](#java-dbg-tool)
    - [IDE调试器 jvisual agent](#ide调试器-jvisual-agent)

<!-- /TOC -->

# dbg method 

## ** method invoke trace n param
## use log dft gene log 
## error invoke StackList  n cur param
## use api to trace invoke
## use tool to trace meth(param)


# .... log
## web acc url n param
## vm log dft no 
## db log..mysql log

# trance lib api 各种拦截api aop

## web fltre machi
## vm api invoke trance api
## db trigger,,
## api埋点

# gui tool 

 

# java dbg tool

## IDE调试器 jvisual agent
 jvisual.exe 

 ，agent是其中很重要的一个模块