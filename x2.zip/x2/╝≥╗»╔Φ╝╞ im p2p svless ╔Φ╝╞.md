简化设计 im p2p  svless 设计


# reg login  kyc use  key密钥即可
# im p2p

