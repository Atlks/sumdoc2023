oversea life cost



ilyao baosye  1500u per yr...


 年假：15天-20天 一年涨一天
 病假：15天
 假期 双休 当地节假日