rule naming


id sanyaosu name,bday ,pic
loc



so name is      tm202311mkt_gh  just a good name