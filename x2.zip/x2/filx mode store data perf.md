filx mode store data perf



 file append	1.5w ps
buffer   1kwps


