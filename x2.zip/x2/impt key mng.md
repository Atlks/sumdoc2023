impt key mng

kyid

not hd id...byid is better


# encry

伪装围绕。。
移位法，，不要置换法。。

